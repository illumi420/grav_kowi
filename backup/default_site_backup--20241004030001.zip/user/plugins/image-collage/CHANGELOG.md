# v1.0.4
## 06/06/2016

1. [](#bugfix)
    * Fix default config load
    * Fix syntax in readme

# v1.0.3
## 06/01/2016

1. [](#bugfix)
    * Fix bug, it is necessary to `replace image_collage.php` -> `image-collage.php`, `image_collage.yaml` -> `image-collage.yaml`

# v1.0.2
## 06/01/2016

1. [](#bugfix)
    * Fixed date format in CHANGELOG

# v1.0.1
## 06/01/2016

1. [](#bugfix)
    * Fixed documentation by install command

# v1.0.0
## 05/28/2016

1. [](#new)
    * Added `image_collage(images: ImageMedium[], column: int, borderSize: int, width: int): ImageMedium` Twig Extension
