---
title: Plugins
expires: 0

access:
    admin.plugins: true
    admin.super: true
---
